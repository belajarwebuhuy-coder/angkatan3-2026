<?php

/**
 * -----------------------------------------------------
 * Personal Portfolio CMS
 * Module       : Database Connection
 * Description  : Menyediakan koneksi PDO tunggal (singleton)
 *                ke database MySQL. Seluruh query pada project
 *                wajib menggunakan koneksi ini dengan
 *                prepared statement.
 * Author       : Wahyu Subuh
 * -----------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';

final class Database
{
    private static ?PDO $connection = null;

    private function __construct()
    {
    }

    public static function getConnection(): PDO
    {
        if (self::$connection instanceof PDO) {
            return self::$connection;
        }

        $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
        ];

        try {
            self::$connection = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $exception) {
            error_log('Database connection failed: ' . $exception->getMessage());

            throw new RuntimeException(
                'Tidak dapat terhubung ke database. Silakan coba beberapa saat lagi.'
            );
        }

        return self::$connection;
    }
}

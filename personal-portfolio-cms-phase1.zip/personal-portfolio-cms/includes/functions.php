<?php

/**
 * -----------------------------------------------------
 * Personal Portfolio CMS
 * Module       : Core Helper Functions
 * Description  : Kumpulan fungsi bantu dasar yang bersifat
 *                umum dan dipakai lintas modul. Helper yang
 *                spesifik untuk kebutuhan CMS (upload, validasi,
 *                alert, pagination) dibangun pada Phase 3 - CMS Core
 *                sesuai DOCS 06.
 * Author       : Wahyu Subuh
 * -----------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/config.php';

/**
 * Escape output untuk mencegah XSS.
 */
function e(?string $value): string
{
    return htmlspecialchars($value ?? '', ENT_QUOTES, 'UTF-8');
}

/**
 * Membangun URL menuju file pada folder assets/.
 */
function asset(string $path): string
{
    return ASSETS_URL . '/' . ltrim($path, '/');
}

/**
 * Membangun URL menuju file hasil upload pada modul tertentu.
 * Contoh: uploadUrl('projects', 'thumbnail.webp')
 */
function uploadUrl(string $module, string $filename): string
{
    return UPLOAD_URL . '/' . trim($module, '/') . '/' . ltrim($filename, '/');
}

/**
 * Redirect ke path relatif terhadap BASE_URL lalu menghentikan eksekusi.
 */
function redirectTo(string $path): void
{
    header('Location: ' . BASE_URL . '/' . ltrim($path, '/'));
    exit;
}

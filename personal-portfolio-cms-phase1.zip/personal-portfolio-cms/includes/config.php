<?php

/**
 * -----------------------------------------------------
 * Personal Portfolio CMS
 * Module       : Core Configuration
 * Description  : Konfigurasi environment, konstanta aplikasi,
 *                dan pengaturan dasar PHP. File ini menjadi
 *                titik masuk konfigurasi yang di-include oleh
 *                seluruh halaman (frontend maupun admin).
 * Author       : Wahyu Subuh
 * -----------------------------------------------------
 */

declare(strict_types=1);

// -----------------------------------------------------
// Environment
// -----------------------------------------------------
// Ganti menjadi 'production' saat aplikasi sudah di-deploy.
// Lihat DOCS 06 - Phase 15 (Deployment) untuk konfigurasi production.
define('APP_ENV', 'development');

if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
}

// Detail error tetap dicatat ke log meskipun tidak ditampilkan ke user.
// Lokasi log mengikuti konfigurasi default PHP/Apache (Laragon).
ini_set('log_errors', '1');

// -----------------------------------------------------
// Timezone
// -----------------------------------------------------
date_default_timezone_set('Asia/Jakarta');

// -----------------------------------------------------
// Application Constants
// -----------------------------------------------------
define('APP_NAME', 'Personal Portfolio CMS');

// Sesuaikan BASE_URL dengan alamat project pada environment lokal
// (contoh Laragon: http://personal-portfolio-cms.test).
define('BASE_URL', 'http://localhost/personal-portfolio-cms');

// -----------------------------------------------------
// Path Constants
// -----------------------------------------------------
define('ROOT_PATH', dirname(__DIR__));
define('UPLOAD_PATH', ROOT_PATH . '/uploads');
define('UPLOAD_URL', BASE_URL . '/uploads');
define('ASSETS_URL', BASE_URL . '/assets');

// Batas maksimal ukuran file upload (dalam byte).
// Disepakati: 5MB. Digunakan kembali oleh seluruh modul upload pada Phase 3+.
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);

// Tipe file gambar yang diizinkan untuk seluruh modul upload.
define('ALLOWED_IMAGE_TYPES', ['image/jpeg', 'image/png', 'image/webp']);

// -----------------------------------------------------
// Database Constants
// -----------------------------------------------------
// Kredensial default mengikuti konfigurasi default Laragon (root, tanpa password).
// WAJIB disesuaikan sebelum deployment ke production (DOCS 08 - Security Standards).
define('DB_HOST', 'localhost');
define('DB_NAME', 'personal_portfolio_cms');
define('DB_USER', 'root');
define('DB_PASS', '');
define('DB_CHARSET', 'utf8mb4');

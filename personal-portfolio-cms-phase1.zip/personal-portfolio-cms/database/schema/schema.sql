-- =====================================================
-- Personal Portfolio CMS
-- Database Schema
-- Reference : DOCS 05 - DATABASE_DESIGN.md (Approved)
--             + Amandemen hasil persetujuan (lihat catatan di bawah)
-- Engine    : MySQL 8.0 / InnoDB / utf8mb4
-- =====================================================

-- Catatan Amandemen (disetujui sebelum Phase 1 dimulai):
-- 1. Tabel `settings` mendapat tambahan kolom:
--    primary_color, secondary_color   -> Theme Color (selaras DOCS 01 seksi 11)
--    map_latitude, map_longitude      -> kebutuhan Google Maps pada Contact Section
-- 2. Kolom `settings.youtube` TETAP dipertahankan (tidak dihapus).
-- Perubahan ini TIDAK menambah/menghapus tabel maupun mengubah nama field
-- yang telah disepakati di luar dari yang tercatat di atas.

CREATE DATABASE IF NOT EXISTS `personal_portfolio_cms`
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_unicode_ci;

USE `personal_portfolio_cms`;

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- =====================================================
-- TABLE : users
-- =====================================================
CREATE TABLE `users` (
    `id`         BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`       VARCHAR(100)  NOT NULL,
    `email`      VARCHAR(150)  NOT NULL,
    `password`   VARCHAR(255)  NOT NULL,
    `photo`      VARCHAR(255)  NULL,
    `created_at` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at` TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_users_email` (`email`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : settings
-- =====================================================
CREATE TABLE `settings` (
    `id`                   BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `website_name`         VARCHAR(150) NULL,
    `logo`                 VARCHAR(255) NULL,
    `favicon`              VARCHAR(255) NULL,
    `owner_name`           VARCHAR(150) NULL,
    `owner_profession`     VARCHAR(150) NULL,
    `owner_photo`          VARCHAR(255) NULL,
    `email`                VARCHAR(150) NULL,
    `phone`                VARCHAR(50)  NULL,
    `address`              VARCHAR(255) NULL,
    `map_latitude`         DECIMAL(10, 7) NULL,
    `map_longitude`        DECIMAL(10, 7) NULL,
    `github`               VARCHAR(255) NULL,
    `linkedin`             VARCHAR(255) NULL,
    `instagram`            VARCHAR(255) NULL,
    `facebook`             VARCHAR(255) NULL,
    `x`                    VARCHAR(255) NULL,
    `youtube`              VARCHAR(255) NULL,
    `meta_title`           VARCHAR(255) NULL,
    `meta_description`     VARCHAR(255) NULL,
    `google_verification`  VARCHAR(255) NULL,
    `primary_color`        VARCHAR(7)   NULL,
    `secondary_color`      VARCHAR(7)   NULL,
    `default_dark_mode`    TINYINT(1)   NOT NULL DEFAULT 0,
    `maintenance_mode`     TINYINT(1)   NOT NULL DEFAULT 0,
    `created_at`           TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`           TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : hero
-- =====================================================
CREATE TABLE `hero` (
    `id`            BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `greeting`      VARCHAR(150) NULL,
    `title`         VARCHAR(150) NULL,
    `profession`    VARCHAR(150) NULL,
    `description`   TEXT NULL,
    `hero_image`    VARCHAR(255) NULL,
    `button1_text`  VARCHAR(100) NULL,
    `button1_link`  VARCHAR(255) NULL,
    `button2_text`  VARCHAR(100) NULL,
    `button2_link`  VARCHAR(255) NULL,
    `created_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`    TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : about
-- =====================================================
CREATE TABLE `about` (
    `id`           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `photo`        VARCHAR(255) NULL,
    `title`        VARCHAR(150) NULL,
    `description`  TEXT NULL,
    `birth_date`   DATE NULL,
    `location`     VARCHAR(150) NULL,
    `email`        VARCHAR(150) NULL,
    `phone`        VARCHAR(50) NULL,
    `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : education
-- =====================================================
CREATE TABLE `education` (
    `id`           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `institution`  VARCHAR(150) NOT NULL,
    `degree`       VARCHAR(150) NULL,
    `start_year`   YEAR NULL,
    `end_year`     YEAR NULL,
    `description`  TEXT NULL,
    `sort_order`   INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : experience
-- =====================================================
CREATE TABLE `experience` (
    `id`           BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `company`      VARCHAR(150) NOT NULL,
    `position`     VARCHAR(150) NULL,
    `start_date`   DATE NULL,
    `end_date`     DATE NULL,
    `description`  TEXT NULL,
    `sort_order`   INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : skills
-- =====================================================
CREATE TABLE `skills` (
    `id`          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(100) NOT NULL,
    `percentage`  TINYINT UNSIGNED NOT NULL DEFAULT 0,
    `sort_order`  INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `chk_skills_percentage` CHECK (`percentage` BETWEEN 0 AND 100)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : certificates
-- =====================================================
CREATE TABLE `certificates` (
    `id`               BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`            VARCHAR(150) NOT NULL,
    `issuer`           VARCHAR(150) NULL,
    `issue_date`       DATE NULL,
    `credential_id`    VARCHAR(150) NULL,
    `credential_url`   VARCHAR(255) NULL,
    `image`            VARCHAR(255) NULL,
    `sort_order`       INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : projects
-- =====================================================
CREATE TABLE `projects` (
    `id`                  BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`               VARCHAR(150) NOT NULL,
    `slug`                VARCHAR(180) NOT NULL,
    `thumbnail`           VARCHAR(255) NULL,
    `short_description`   VARCHAR(255) NULL,
    `description`         TEXT NULL,
    `tech_stack`          VARCHAR(255) NULL,
    `github_url`          VARCHAR(255) NULL,
    `demo_url`            VARCHAR(255) NULL,
    `featured`            TINYINT(1) NOT NULL DEFAULT 0,
    `status`              ENUM('draft', 'published') NOT NULL DEFAULT 'draft',
    `created_at`          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_projects_slug` (`slug`),
    INDEX `idx_projects_status` (`status`),
    INDEX `idx_projects_featured` (`featured`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : project_images
-- =====================================================
CREATE TABLE `project_images` (
    `id`          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `project_id`  BIGINT UNSIGNED NOT NULL,
    `image`       VARCHAR(255) NOT NULL,
    `sort_order`  INT UNSIGNED NOT NULL DEFAULT 0,
    `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT `fk_project_images_project`
        FOREIGN KEY (`project_id`) REFERENCES `projects` (`id`)
        ON DELETE CASCADE
        ON UPDATE CASCADE
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : blogs
-- =====================================================
CREATE TABLE `blogs` (
    `id`             BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `title`          VARCHAR(150) NOT NULL,
    `slug`           VARCHAR(180) NOT NULL,
    `thumbnail`      VARCHAR(255) NULL,
    `summary`        VARCHAR(255) NULL,
    `content`        LONGTEXT NULL,
    `tags`           VARCHAR(255) NULL,
    `status`         ENUM('draft', 'published') NOT NULL DEFAULT 'draft',
    `published_at`   DATETIME NULL,
    `created_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    `updated_at`     TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY `uq_blogs_slug` (`slug`),
    INDEX `idx_blogs_status` (`status`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

-- =====================================================
-- TABLE : messages
-- =====================================================
CREATE TABLE `messages` (
    `id`          BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    `name`        VARCHAR(150) NOT NULL,
    `email`       VARCHAR(150) NOT NULL,
    `subject`     VARCHAR(255) NULL,
    `message`     TEXT NOT NULL,
    `is_read`     TINYINT(1) NOT NULL DEFAULT 0,
    `created_at`  TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX `idx_messages_is_read` (`is_read`)
) ENGINE = InnoDB DEFAULT CHARSET = utf8mb4 COLLATE = utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

<?php

/**
 * -----------------------------------------------------
 * Personal Portfolio CMS
 * Module       : Project Initialization (Phase 1)
 * Description  : Halaman verifikasi sementara untuk memastikan
 *                konfigurasi PHP dan koneksi database berjalan
 *                dengan baik. File ini akan digantikan oleh
 *                halaman frontend EasyFolio pada Phase 11 -
 *                Frontend Integration (DOCS 06).
 * Author       : Wahyu Subuh
 * -----------------------------------------------------
 */

declare(strict_types=1);

require_once __DIR__ . '/includes/config.php';
require_once __DIR__ . '/includes/database.php';
require_once __DIR__ . '/includes/functions.php';

$databaseStatus = false;
$databaseMessage = '';

try {
    Database::getConnection();
    $databaseStatus = true;
    $databaseMessage = 'Koneksi database berhasil.';
} catch (RuntimeException $exception) {
    $databaseMessage = $exception->getMessage();
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= e(APP_NAME) ?> - Phase 1 Verification</title>
</head>
<body>
    <h1><?= e(APP_NAME) ?></h1>
    <p>Status: Phase 1 - Project Initialization</p>
    <p>PHP Version: <?= e(PHP_VERSION) ?></p>
    <p>Environment: <?= e(APP_ENV) ?></p>
    <p>Database: <?= $databaseStatus ? 'Terhubung' : 'Gagal terhubung' ?> - <?= e($databaseMessage) ?></p>
    <p><em>Halaman ini bersifat sementara dan akan digantikan oleh frontend EasyFolio pada Phase 11.</em></p>
</body>
</html>

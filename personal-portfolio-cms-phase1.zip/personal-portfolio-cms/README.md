# Personal Portfolio CMS

Status: **Phase 1 - Project Initialization** (lihat `docs/06_DEVELOPMENT_ROADMAP.md`)

## Cara Menjalankan (Local - Laragon)

1. Salin folder project ini ke dalam direktori www Laragon.
2. Buka phpMyAdmin, lalu import `database/schema/schema.sql`.
   Perintah ini akan membuat database `personal_portfolio_cms` beserta 12 tabel sesuai
   `docs/05_DATABASE_DESIGN.md`.
3. Buka `includes/config.php`, sesuaikan konstanta berikut jika perlu:
   - `BASE_URL`
   - `DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`
4. Akses project melalui browser, contoh: `http://personal-portfolio-cms.test`
   atau `http://localhost/personal-portfolio-cms`.
5. Jika halaman menampilkan **"Database: Terhubung"**, Phase 1 berhasil diverifikasi.

## Status Modul

Halaman `index.php` saat ini adalah **halaman verifikasi sementara** untuk
memastikan konfigurasi PHP dan koneksi database berjalan. Halaman ini akan
digantikan oleh frontend EasyFolio pada **Phase 11 - Frontend Integration**.

## Dokumentasi

Seluruh dokumentasi acuan project (DOCS 01-10) tersedia pada folder `docs/`.
Dokumentasi tersebut adalah sumber kebenaran (source of truth) untuk seluruh
proses development.

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta content="width=device-width, initial-scale=1.0" name="viewport">
    <title>Index - EasyFolio Bootstrap Template</title>
    <meta name="description" content="">
    <meta name="keywords" content="">

    <!-- Favicons -->
    <link href="assets/img/favicon.png" rel="icon">
    <link href="assets/img/apple-touch-icon.png" rel="apple-touch-icon">

    <!-- Fonts -->
    <link href="https://fonts.googleapis.com" rel="preconnect">
    <link href="https://fonts.gstatic.com" rel="preconnect" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Roboto:ital,wght@0,100;0,300;0,400;0,500;0,700;0,900;1,100;1,300;1,400;1,500;1,700;1,900&family=Noto+Sans:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900;1,100;1,200;1,300;1,400;1,500;1,600;1,700;1,800;1,900&family=Questrial:wght@400&display=swap"
        rel="stylesheet">

    <!-- Vendor CSS Files -->
    <link href="assets/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="assets/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
    <link href="assets/vendor/aos/aos.css" rel="stylesheet">
    <link href="assets/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
    <link href="assets/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">

    <!-- Main CSS File -->
    <link href="assets/css/main.css" rel="stylesheet">

    <!-- =======================================================
  * Template Name: EasyFolio
  * Template URL: https://bootstrapmade.com/easyfolio-bootstrap-portfolio-template/
  * Updated: Feb 21 2025 with Bootstrap v5.3.3
  * Author: BootstrapMade.com
  * License: https://bootstrapmade.com/license/
  ======================================================== -->
</head>

<body class="index-page">

    <header id="header" class="header d-flex align-items-center sticky-top">
        <div
            class="header-container container-fluid container-xl position-relative d-flex align-items-center justify-content-between">

            <a href="index.html" class="logo d-flex align-items-center me-auto me-xl-0">
                <!-- Uncomment the line below if you also wish to use an image logo -->
                <!-- <img src="assets/img/logo.webp" alt=""> -->
                <h1 class="sitename">EasyFolio</h1>
            </a>

            <nav id="navmenu" class="navmenu">
                <ul>
                    <li><a href="#hero" class="active">Home</a></li>
                    <li><a href="#about">About</a></li>
                    <li><a href="#resume">Resume</a></li>
                    <li><a href="#portfolio">Portfolio</a></li>
                    <li class="dropdown"><a href="#"><span>Dropdown</span> <i
                                class="bi bi-chevron-down toggle-dropdown"></i></a>
                        <ul>
                            <li><a href="#">Dropdown 1</a></li>
                            <li class="dropdown"><a href="#"><span>Deep Dropdown</span> <i
                                        class="bi bi-chevron-down toggle-dropdown"></i></a>
                                <ul>
                                    <li><a href="#">Deep Dropdown 1</a></li>
                                    <li><a href="#">Deep Dropdown 2</a></li>
                                    <li><a href="#">Deep Dropdown 3</a></li>
                                    <li><a href="#">Deep Dropdown 4</a></li>
                                    <li><a href="#">Deep Dropdown 5</a></li>
                                </ul>
                            </li>
                            <li><a href="#">Dropdown 2</a></li>
                            <li><a href="#">Dropdown 3</a></li>
                            <li><a href="#">Dropdown 4</a></li>
                        </ul>
                    </li>
                    <li><a href="#contact">Contact</a></li>
                </ul>
                <i class="mobile-nav-toggle d-xl-none bi bi-list"></i>
            </nav>

            <div class="header-social-links">
                <a href="#" class="twitter"><i class="bi bi-twitter-x"></i></a>
                <a href="#" class="facebook"><i class="bi bi-facebook"></i></a>
                <a href="#" class="instagram"><i class="bi bi-instagram"></i></a>
                <a href="#" class="linkedin"><i class="bi bi-linkedin"></i></a>
            </div>

        </div>
    </header>

    <main class="main">

        <!-- Hero Section -->
        <section id="hero" class="hero section">

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row align-items-center content">
                    <div class="col-lg-6" data-aos="fade-up" data-aos-delay="200">
                        <h2>Crafting Digital Experiences with Passion</h2>
                        <p class="lead">Transforming ideas into elegant solutions through creative design and innovative
                            development</p>
                        <div class="cta-buttons" data-aos="fade-up" data-aos-delay="300">
                            <a href="#portfolio" class="btn btn-primary">View My Work</a>
                            <a href="#contact" class="btn btn-outline">Let's Connect</a>
                        </div>
                        <div class="hero-stats" data-aos="fade-up" data-aos-delay="400">
                            <div class="stat-item">
                                <span class="stat-number">5+</span>
                                <span class="stat-label">Years Experience</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number">100+</span>
                                <span class="stat-label">Projects Completed</span>
                            </div>
                            <div class="stat-item">
                                <span class="stat-number">50+</span>
                                <span class="stat-label">Happy Clients</span>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="hero-image">
                            <img src="assets/img/profile/profile-1.webp" alt="Portfolio Hero Image" class="img-fluid"
                                data-aos="zoom-out" data-aos-delay="300">
                            <div class="shape-1"></div>
                            <div class="shape-2"></div>
                        </div>
                    </div>
                </div>

            </div>

        </section><!-- /Hero Section -->

        <!-- About Section -->
        <section id="about" class="about section light-background">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>About</h2>
                <div class="title-shape">
                    <svg viewBox="0 0 200 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M 0,10 C 40,0 60,20 100,10 C 140,0 160,20 200,10" fill="none" stroke="currentColor"
                            stroke-width="2"></path>
                    </svg>
                </div>
                <p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur
                    vel illum qui dolorem</p>
            </div><!-- End Section Title -->

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row align-items-center">
                    <div class="col-lg-6 position-relative" data-aos="fade-right" data-aos-delay="200">
                        <div class="about-image">
                            <img src="assets/img/profile/profile-square-2.webp" alt="Profile Image"
                                class="img-fluid rounded-4">
                        </div>
                    </div>

                    <div class="col-lg-6" data-aos="fade-left" data-aos-delay="300">
                        <div class="about-content">
                            <span class="subtitle">About Me</span>

                            <h2>UI/UX Designer &amp; Web Developer</h2>

                            <p class="lead mb-4">Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut
                                fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
                            </p>

                            <p class="mb-4">Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet</p>

                            <div class="personal-info">
                                <div class="row g-4">
                                    <div class="col-6">
                                        <div class="info-item">
                                            <span class="label">Name</span>
                                            <span class="value">Eliot Johnson</span>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-item">
                                            <span class="label">Phone</span>
                                            <span class="value">+123 456 7890</span>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-item">
                                            <span class="label">Age</span>
                                            <span class="value">26 Years</span>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-item">
                                            <span class="label">Email</span>
                                            <span class="value">email@example.com</span>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-item">
                                            <span class="label">Occupation</span>
                                            <span class="value">Lorem Engineer</span>
                                        </div>
                                    </div>

                                    <div class="col-6">
                                        <div class="info-item">
                                            <span class="label">Nationality</span>
                                            <span class="value">Ipsum</span>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="signature mt-4">
                                <div class="signature-image">
                                    <img src="assets/img/misc/signature-1.webp" alt="" class="img-fluid">
                                </div>
                                <div class="signature-info">
                                    <h4>Eliot Johnson</h4>
                                    <p>Adipiscing Elit, Lorem Ipsum</p>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </section><!-- /About Section -->

        <!-- Skills Section -->
        <section id="skills" class="skills section">

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row g-4 skills-animation">

                    <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="100">
                        <div class="skill-box">
                            <h3>HTML</h3>
                            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem.</p>
                            <span class="text-end d-block">90%</span>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="90" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="200">
                        <div class="skill-box">
                            <h3>CSS</h3>
                            <p>Nemo enim ipsam voluptatem quia voluptas sit aspernatur.</p>
                            <span class="text-end d-block">90%</span>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="95" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="300">
                        <div class="skill-box">
                            <h3>JavaScript</h3>
                            <p>Neque porro quisquam est qui dolorem ipsum quia dolor.</p>
                            <span class="text-end d-block">80%</span>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="80" aria-valuemin="0"
                                    aria-valuemax="100"></div>
                            </div>
                        </div>
                    </div>

                    <div class="col-md-6 col-lg-3" data-aos="fade-up" data-aos-delay="400">
                        <div class="skill-box">
                            <h3>Photoshop</h3>
                            <p>Quis autem vel eum iure reprehenderit qui in ea voluptate.</p>
                            <span class="text-end d-block">55%</span>
                            <div class="progress">
                                <div class="progress-bar" role="progressbar" aria-valuenow="55" aria-valuemin="0"
                                    aria-valuemax="100">
                                </div>
                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </section><!-- /Skills Section -->

        <!-- Resume Section -->
        <section id="resume" class="resume section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Resume</h2>
                <div class="title-shape">
                    <svg viewBox="0 0 200 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M 0,10 C 40,0 60,20 100,10 C 140,0 160,20 200,10" fill="none" stroke="currentColor"
                            stroke-width="2"></path>
                    </svg>
                </div>
                <p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur
                    vel illum qui dolorem</p>
            </div><!-- End Section Title -->

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row">
                    <div class="col-12">
                        <div class="resume-wrapper">
                            <div class="resume-block" data-aos="fade-up">
                                <h2>Work Experience</h2>
                                <p class="lead">Maecenas tempus tellus eget condimentum rhoncus sem quam semper libero
                                    sit amet adipiscing sem neque sed ipsum.</p>

                                <div class="timeline">
                                    <div class="timeline-item" data-aos="fade-up" data-aos-delay="200">
                                        <div class="timeline-left">
                                            <h4 class="company">Etiam Industries</h4>
                                            <span class="period">Jun, 2023 - Current</span>
                                        </div>
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-right">
                                            <h3 class="position">Project Lead</h3>
                                            <p class="description">Quia nobis sequi est occaecati aut. Repudiandae et
                                                iusto quae reiciendis et quis Eius vel ratione eius unde vitae rerum
                                                voluptates asperiores voluptatem Earum molestiae consequatur neque etlon
                                                sader mart dila</p>
                                        </div>
                                    </div>

                                    <div class="timeline-item" data-aos="fade-up" data-aos-delay="300">
                                        <div class="timeline-left">
                                            <h4 class="company">Nullam Corp</h4>
                                            <span class="period">2019 - 2023</span>
                                        </div>
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-right">
                                            <h3 class="position">Senior graphic design specialist</h3>
                                            <p class="description">
                                                Curabitur ullamcorper ultricies nisi nam eget dui etiam rhoncus maecenas
                                                tempus.
                                            </p>
                                            <ul>
                                                <li>Lead in the design, development, and implementation of the graphic,
                                                    layout, and production communication materials</li>
                                                <li>Delegate tasks to the 7 members of the design team and provide
                                                    counsel on all aspects of the project. </li>
                                                <li>Supervise the assessment of all graphic materials in order to ensure
                                                    quality and accuracy of the design</li>
                                                <li>Oversee the efficient use of production project budgets ranging from
                                                    $2,000 - $25,000</li>
                                            </ul>
                                            <p></p>
                                        </div>
                                    </div>

                                    <div class="timeline-item" data-aos="fade-up" data-aos-delay="400">
                                        <div class="timeline-left">
                                            <h4 class="company">Stepping Stone Ltd.</h4>
                                            <span class="period">2015-2019</span>
                                        </div>
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-right">
                                            <h3 class="position">Graphic design specialist</h3>
                                            <p class="description">Curabitur ullamcorper ultricies nisi nam eget dui
                                                etiam rhoncus maecenas tempus.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="resume-block" data-aos="fade-up" data-aos-delay="100">
                                <h2>My Education</h2>
                                <p class="lead">Maecenas tempus tellus eget condimentum rhoncus sem quam semper libero
                                    sit amet adipiscing.</p>

                                <div class="timeline">
                                    <div class="timeline-item" data-aos="fade-up" data-aos-delay="200">
                                        <div class="timeline-left">
                                            <h4 class="company">Vestibulum University</h4>
                                            <span class="period">2017-2019</span>
                                        </div>
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-right">
                                            <h3 class="position">Diploma in Consequat</h3>
                                            <p class="description">Curabitur ullamcorper ultricies nisi nam eget dui
                                                etiam rhoncus maecenas tempus.</p>
                                        </div>
                                    </div>

                                    <div class="timeline-item" data-aos="fade-up" data-aos-delay="300">
                                        <div class="timeline-left">
                                            <h4 class="company">Nullam Corp</h4>
                                            <span class="period">2019 - 2023</span>
                                        </div>
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-right">
                                            <h3 class="position">Master of Fine Arts &amp; Graphic Design</h3>
                                            <p class="description">Curabitur ullamcorper ultricies nisi nam eget dui
                                                etiam rhoncus maecenas tempus.</p>
                                        </div>
                                    </div>

                                    <div class="timeline-item" data-aos="fade-up" data-aos-delay="400">
                                        <div class="timeline-left">
                                            <h4 class="company">Vestibulum University</h4>
                                            <span class="period">2015-2019</span>
                                        </div>
                                        <div class="timeline-dot"></div>
                                        <div class="timeline-right">
                                            <h3 class="position">Bachelor of Fine Arts &amp; Graphic Design</h3>
                                            <p class="description">Curabitur ullamcorper ultricies nisi nam eget dui
                                                etiam rhoncus maecenas tempus.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>

        </section><!-- /Resume Section -->

        <!-- Portfolio Section -->
        <section id="portfolio" class="portfolio section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Portfolio</h2>
                <div class="title-shape">
                    <svg viewBox="0 0 200 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M 0,10 C 40,0 60,20 100,10 C 140,0 160,20 200,10" fill="none" stroke="currentColor"
                            stroke-width="2"></path>
                    </svg>
                </div>
                <p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur
                    vel illum qui dolorem</p>
            </div><!-- End Section Title -->

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="isotope-layout" data-default-filter="*" data-layout="masonry" data-sort="original-order">

                    <div class="portfolio-filters-container" data-aos="fade-up" data-aos-delay="200">
                        <ul class="portfolio-filters isotope-filters">
                            <li data-filter="*" class="filter-active">All Work</li>
                            <li data-filter=".filter-web">Web Design</li>
                            <li data-filter=".filter-graphics">Graphics</li>
                            <li data-filter=".filter-motion">Motion</li>
                            <li data-filter=".filter-brand">Branding</li>
                        </ul>
                    </div>

                    <div class="row g-4 isotope-container" data-aos="fade-up" data-aos-delay="300">

                        <div class="col-lg-6 col-md-6 portfolio-item isotope-item filter-web">
                            <div class="portfolio-card">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/portfolio-1.webp" class="img-fluid" alt=""
                                        loading="lazy">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="assets/img/portfolio/portfolio-1.webp"
                                                class="glightbox preview-link" data-gallery="portfolio-gallery-web"><i
                                                    class="bi bi-eye"></i></a>
                                            <a href="portfolio-details.html" class="details-link"><i
                                                    class="bi bi-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <span class="category">Web Design</span>
                                    <h3>Modern Dashboard Interface</h3>
                                    <p>Maecenas faucibus mollis interdum sed posuere consectetur est at lobortis.</p>
                                </div>
                            </div>
                        </div><!-- End Portfolio Item -->

                        <div class="col-lg-6 col-md-6 portfolio-item isotope-item filter-graphics">
                            <div class="portfolio-card">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/portfolio-10.webp" class="img-fluid" alt=""
                                        loading="lazy">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="assets/img/portfolio/portfolio-10.webp"
                                                class="glightbox preview-link"
                                                data-gallery="portfolio-gallery-graphics"><i class="bi bi-eye"></i></a>
                                            <a href="portfolio-details.html" class="details-link"><i
                                                    class="bi bi-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <span class="category">Graphics</span>
                                    <h3>Creative Brand Identity</h3>
                                    <p>Vestibulum id ligula porta felis euismod semper at vulputate.</p>
                                </div>
                            </div>
                        </div><!-- End Portfolio Item -->

                        <div class="col-lg-6 col-md-6 portfolio-item isotope-item filter-motion">
                            <div class="portfolio-card">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/portfolio-7.webp" class="img-fluid" alt=""
                                        loading="lazy">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="assets/img/portfolio/portfolio-7.webp"
                                                class="glightbox preview-link"
                                                data-gallery="portfolio-gallery-motion"><i class="bi bi-eye"></i></a>
                                            <a href="portfolio-details.html" class="details-link"><i
                                                    class="bi bi-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <span class="category">Motion</span>
                                    <h3>Product Animation Reel</h3>
                                    <p>Donec ullamcorper nulla non metus auctor fringilla dapibus.</p>
                                </div>
                            </div>
                        </div><!-- End Portfolio Item -->

                        <div class="col-lg-6 col-md-6 portfolio-item isotope-item filter-brand">
                            <div class="portfolio-card">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/portfolio-4.webp" class="img-fluid" alt=""
                                        loading="lazy">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="assets/img/portfolio/portfolio-4.webp"
                                                class="glightbox preview-link" data-gallery="portfolio-gallery-brand"><i
                                                    class="bi bi-eye"></i></a>
                                            <a href="portfolio-details.html" class="details-link"><i
                                                    class="bi bi-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <span class="category">Branding</span>
                                    <h3>Luxury Brand Package</h3>
                                    <p>Aenean lacinia bibendum nulla sed consectetur elit.</p>
                                </div>
                            </div>
                        </div><!-- End Portfolio Item -->

                        <div class="col-lg-6 col-md-6 portfolio-item isotope-item filter-web">
                            <div class="portfolio-card">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/portfolio-2.webp" class="img-fluid" alt=""
                                        loading="lazy">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="assets/img/portfolio/portfolio-2.webp"
                                                class="glightbox preview-link" data-gallery="portfolio-gallery-web"><i
                                                    class="bi bi-eye"></i></a>
                                            <a href="portfolio-details.html" class="details-link"><i
                                                    class="bi bi-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <span class="category">Web Design</span>
                                    <h3>E-commerce Platform</h3>
                                    <p>Nullam id dolor id nibh ultricies vehicula ut id elit.</p>
                                </div>
                            </div>
                        </div><!-- End Portfolio Item -->

                        <div class="col-lg-6 col-md-6 portfolio-item isotope-item filter-graphics">
                            <div class="portfolio-card">
                                <div class="portfolio-image">
                                    <img src="assets/img/portfolio/portfolio-11.webp" class="img-fluid" alt=""
                                        loading="lazy">
                                    <div class="portfolio-overlay">
                                        <div class="portfolio-actions">
                                            <a href="assets/img/portfolio/portfolio-11.webp"
                                                class="glightbox preview-link"
                                                data-gallery="portfolio-gallery-graphics"><i class="bi bi-eye"></i></a>
                                            <a href="portfolio-details.html" class="details-link"><i
                                                    class="bi bi-arrow-right"></i></a>
                                        </div>
                                    </div>
                                </div>
                                <div class="portfolio-content">
                                    <span class="category">Graphics</span>
                                    <h3>Digital Art Collection</h3>
                                    <p>Cras mattis consectetur purus sit amet fermentum.</p>
                                </div>
                            </div>
                        </div><!-- End Portfolio Item -->

                    </div><!-- End Portfolio Container -->

                </div>

            </div>

        </section><!-- /Portfolio Section -->

        <!-- Faq Section -->
        <section id="faq" class="faq section">

            <!-- Section Title -->
            <div class="container section-title" data-aos="fade-up">
                <h2>Frequently Asked Questions</h2>
                <div class="title-shape">
                    <svg viewBox="0 0 200 20" xmlns="http://www.w3.org/2000/svg">
                        <path d="M 0,10 C 40,0 60,20 100,10 C 140,0 160,20 200,10" fill="none" stroke="currentColor"
                            stroke-width="2"></path>
                    </svg>
                </div>
                <p>Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur
                    vel illum qui dolorem</p>
            </div><!-- End Section Title -->

            <div class="container">

                <div class="row justify-content-center">

                    <div class="col-lg-10" data-aos="fade-up" data-aos-delay="100">

                        <div class="faq-container">

                            <div class="faq-item faq-active">
                                <h3>Non consectetur a erat nam at lectus urna duis?</h3>
                                <div class="faq-content">
                                    <p>Feugiat pretium nibh ipsum consequat. Tempus iaculis urna id volutpat lacus
                                        laoreet non curabitur gravida. Venenatis lectus magna fringilla urna porttitor
                                        rhoncus dolor purus non.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div><!-- End Faq item-->

                            <div class="faq-item">
                                <h3>Feugiat scelerisque varius morbi enim nunc faucibus?</h3>
                                <div class="faq-content">
                                    <p>Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id
                                        interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus
                                        scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim.
                                        Mauris ultrices eros in cursus turpis massa tincidunt dui.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div><!-- End Faq item-->

                            <div class="faq-item">
                                <h3>Dolor sit amet consectetur adipiscing elit pellentesque?</h3>
                                <div class="faq-content">
                                    <p>Eleifend mi in nulla posuere sollicitudin aliquam ultrices sagittis orci.
                                        Faucibus pulvinar elementum integer enim. Sem nulla pharetra diam sit amet nisl
                                        suscipit. Rutrum tellus pellentesque eu tincidunt. Lectus urna duis convallis
                                        convallis tellus. Urna molestie at elementum eu facilisis sed odio morbi quis
                                    </p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div><!-- End Faq item-->

                            <div class="faq-item">
                                <h3>Ac odio tempor orci dapibus. Aliquam eleifend mi in nulla?</h3>
                                <div class="faq-content">
                                    <p>Dolor sit amet consectetur adipiscing elit pellentesque habitant morbi. Id
                                        interdum velit laoreet id donec ultrices. Fringilla phasellus faucibus
                                        scelerisque eleifend donec pretium. Est pellentesque elit ullamcorper dignissim.
                                        Mauris ultrices eros in cursus turpis massa tincidunt dui.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div><!-- End Faq item-->

                            <div class="faq-item">
                                <h3>Tempus quam pellentesque nec nam aliquam sem et tortor?</h3>
                                <div class="faq-content">
                                    <p>Molestie a iaculis at erat pellentesque adipiscing commodo. Dignissim suspendisse
                                        in est ante in. Nunc vel risus commodo viverra maecenas accumsan. Sit amet nisl
                                        suscipit adipiscing bibendum est. Purus gravida quis blandit turpis cursus in
                                    </p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div><!-- End Faq item-->

                            <div class="faq-item">
                                <h3>Perspiciatis quod quo quos nulla quo illum ullam?</h3>
                                <div class="faq-content">
                                    <p>Enim ea facilis quaerat voluptas quidem et dolorem. Quis et consequatur non sed
                                        in suscipit sequi. Distinctio ipsam dolore et.</p>
                                </div>
                                <i class="faq-toggle bi bi-chevron-right"></i>
                            </div><!-- End Faq item-->

                        </div>

                    </div><!-- End Faq Column-->

                </div>

            </div>

        </section><!-- /Faq Section -->

        <!-- Contact Section -->
        <section id="contact" class="contact section light-background">

            <div class="container" data-aos="fade-up" data-aos-delay="100">

                <div class="row g-5">
                    <div class="col-lg-6">
                        <div class="content" data-aos="fade-up" data-aos-delay="200">
                            <div class="section-category mb-3">Contact</div>
                            <h2 class="display-5 mb-4">Nemo enim ipsam voluptatem quia voluptas aspernatur</h2>
                            <p class="lead mb-4">Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis
                                suscipit laboriosam.</p>

                            <div class="contact-info mt-5">
                                <div class="info-item d-flex mb-3">
                                    <i class="bi bi-envelope-at me-3"></i>
                                    <span>info@example.com</span>
                                </div>

                                <div class="info-item d-flex mb-3">
                                    <i class="bi bi-telephone me-3"></i>
                                    <span>+1 5589 55488 558</span>
                                </div>

                                <div class="info-item d-flex mb-4">
                                    <i class="bi bi-geo-alt me-3"></i>
                                    <span>A108 Adam Street, New York, NY 535022</span>
                                </div>

                                <a href="#" class="map-link d-inline-flex align-items-center">
                                    Open Map
                                    <i class="bi bi-arrow-right ms-2"></i>
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-6">
                        <div class="contact-form card" data-aos="fade-up" data-aos-delay="300">
                            <div class="card-body p-4 p-lg-5">

                                <form action="forms/contact.php" method="post" class="php-email-form">
                                    <div class="row gy-4">

                                        <div class="col-12">
                                            <input type="text" name="name" class="form-control" placeholder="Your Name"
                                                required="">
                                        </div>

                                        <div class="col-12 ">
                                            <input type="email" class="form-control" name="email"
                                                placeholder="Your Email" required="">
                                        </div>

                                        <div class="col-12">
                                            <input type="text" class="form-control" name="subject" placeholder="Subject"
                                                required="">
                                        </div>

                                        <div class="col-12">
                                            <textarea class="form-control" name="form-contact" rows="6"
                                                placeholder="form-contact" required=""></textarea>
                                        </div>

                                        <div class="col-12 text-center">
                                            <div class="loading">Loading</div>
                                            <div class="error-form-contact"></div>
                                            <div class="sent-form-contact">Your Message has been sent. Thank you!
                                            </div>

                                            <button type="submit" class="btn btn-submit w-100">Submit</button>
                                        </div>

                                    </div>
                                </form>

                            </div>
                        </div>
                    </div>

                </div>

            </div>

        </section><!-- /Contact Section -->

    </main>

    <footer id="footer" class="footer">

        <div class="container">
            <div class="copyright text-center ">
                <p>© <span>Copyright</span> <strong class="px-1 sitename">EasyFolio</strong> <span>All Rights
                        Reserved</span></p>
            </div>
            <div class="social-links d-flex justify-content-center">
                <a href=""><i class="bi bi-twitter-x"></i></a>
                <a href=""><i class="bi bi-facebook"></i></a>
                <a href=""><i class="bi bi-instagram"></i></a>
                <a href=""><i class="bi bi-linkedin"></i></a>
            </div>
            <div class="credits">
                <!-- All the links in the footer should remain intact. -->
                <!-- You can delete the links only if you've purchased the pro version. -->
                <!-- Licensing information: https://bootstrapmade.com/license/ -->
                <!-- Purchase the pro version with working PHP/AJAX contact form: [buy-url] -->
                Designed by <a href="https://bootstrapmade.com/">BootstrapMade</a> | <a
                    href="https://bootstrapmade.com/tools/">DevTools</a>
            </div>
        </div>

    </footer>

    <!-- Scroll Top -->
    <a href="#" id="scroll-top" class="scroll-top d-flex align-items-center justify-content-center"><i
            class="bi bi-arrow-up-short"></i></a>

    <!-- Vendor JS Files -->
    <script src="assets/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="assets/vendor/php-email-form/validate.js"></script>
    <script src="assets/vendor/aos/aos.js"></script>
    <script src="assets/vendor/waypoints/noframework.waypoints.js"></script>
    <script src="assets/vendor/glightbox/js/glightbox.min.js"></script>
    <script src="assets/vendor/imagesloaded/imagesloaded.pkgd.min.js"></script>
    <script src="assets/vendor/isotope-layout/isotope.pkgd.min.js"></script>
    <script src="assets/vendor/swiper/swiper-bundle.min.js"></script>

    <!-- Main JS File -->
    <script src="assets/js/main.js"></script>

</body>

</html>